#include <stdlib.h>
#include <ros/ros.h>
//#include <sensor_msgs/Imu.h>
#include "get_tf.h"
#include "boost/thread.hpp"
float x = 0.0;
float y = 0.0;
float z = 0.0;
int main(int argc, char** argv)
{
	
	ros::init(argc, argv, "PointCloudConvert");
	ros::NodeHandle node;
	tf::StampedTransform tf; 
	Convert convertObject;

	ros::MultiThreadedSpinner s(3);
 	ros::spin(s);
}


